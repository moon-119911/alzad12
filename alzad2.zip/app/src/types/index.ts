export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  university: string;
  major: string;
  level: number;
  bio?: string;
  uploadsCount: number;
  downloadsCount: number;
  joinedAt: string;
}

export interface University {
  id: string;
  name: string;
  logo?: string;
  description?: string;
}

export interface Major {
  id: string;
  name: string;
  universityId: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  majorId: string;
  level: number;
}

export type ContentType = 'lecture' | 'book' | 'summary' | 'exam';

export interface StudyFile {
  id: string;
  title: string;
  description: string;
  fileUrl: string;
  fileType: string;
  fileSize: number;
  contentType: ContentType;
  subject: Subject;
  academicYear: string;
  uploader: User;
  views: number;
  downloads: number;
  rating: number;
  ratingsCount: number;
  createdAt: string;
  isSaved?: boolean;
}

export interface Comment {
  id: string;
  content: string;
  user: User;
  fileId: string;
  createdAt: string;
}

export interface FileRating {
  id: string;
  rating: number;
  userId: string;
  fileId: string;
}

export interface SavedFile {
  id: string;
  file: StudyFile;
  userId: string;
  savedAt: string;
}

export interface FileReport {
  id: string;
  reason: string;
  description?: string;
  userId: string;
  fileId: string;
  status: 'pending' | 'reviewed' | 'resolved';
  createdAt: string;
}

export interface FilterOptions {
  contentType?: ContentType | 'all';
  level?: number | 'all';
  academicYear?: string | 'all';
  sortBy: 'newest' | 'most-downloaded' | 'most-viewed' | 'highest-rated';
}

export interface SearchFilters {
  query: string;
  filters: FilterOptions;
}
