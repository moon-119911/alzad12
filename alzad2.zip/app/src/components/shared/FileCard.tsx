import { useState } from 'react';
import { 
  Download, 
  Eye, 
  Star, 
  Bookmark, 
  MoreVertical,
  FileText,
  BookOpen,
  BookMarked,
  ClipboardList
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { StudyFile, ContentType } from '@/types';
import { contentTypeLabels, contentTypeColors } from '@/data/mockData';

interface FileCardProps {
  file: StudyFile;
  onDownload?: (file: StudyFile) => void;
  onSave?: (file: StudyFile) => void;
  onReport?: (file: StudyFile) => void;
  viewMode?: 'grid' | 'list';
}

const contentTypeIcons: Record<ContentType, React.ReactNode> = {
  lecture: <BookOpen className="w-5 h-5" />,
  book: <BookMarked className="w-5 h-5" />,
  summary: <FileText className="w-5 h-5" />,
  exam: <ClipboardList className="w-5 h-5" />,
};

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

export function FileCard({ 
  file, 
  onDownload, 
  onSave, 
  onReport,
  viewMode = 'grid' 
}: FileCardProps) {
  const [isSaved, setIsSaved] = useState(file.isSaved || false);
  const [isHovered, setIsHovered] = useState(false);

  const handleSave = () => {
    setIsSaved(!isSaved);
    onSave?.(file);
  };

  if (viewMode === 'list') {
    return (
      <div
        className="group relative bg-card border border-border rounded-xl p-4 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="flex items-center gap-4">
          {/* Icon */}
          <div className={`flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center ${contentTypeColors[file.contentType]}`}>
            {contentTypeIcons[file.contentType]}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-foreground truncate">{file.title}</h3>
              <Badge variant="outline" className={`text-xs ${contentTypeColors[file.contentType]}`}>
                {contentTypeLabels[file.contentType]}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground truncate">{file.description}</p>
            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
              <span>{file.subject.name}</span>
              <span>•</span>
              <span>المستوى {file.subject.level}</span>
              <span>•</span>
              <span>{formatFileSize(file.fileSize)}</span>
              <span>•</span>
              <span>{file.academicYear}</span>
            </div>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Eye className="w-4 h-4" />
              <span>{file.views}</span>
            </div>
            <div className="flex items-center gap-1">
              <Download className="w-4 h-4" />
              <span>{file.downloads}</span>
            </div>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span>{file.rating}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className={`transition-colors ${isSaved ? 'text-amber-500' : 'text-muted-foreground'}`}
              onClick={handleSave}
            >
              <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
            </Button>
            <Button
              variant="default"
              size="sm"
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              onClick={() => onDownload?.(file)}
            >
              <Download className="w-4 h-4 ml-2" />
              تحميل
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onReport?.(file)}>
                  الإبلاغ عن محتوى
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="group relative bg-card border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Header with type badge */}
      <div className="relative p-4 pb-0">
        <div className="flex justify-between items-start">
          <Badge className={`${contentTypeColors[file.contentType]} border`}>
            {contentTypeLabels[file.contentType]}
          </Badge>
          <Button
            variant="ghost"
            size="icon"
            className={`h-8 w-8 transition-colors ${isSaved ? 'text-amber-500' : 'text-muted-foreground hover:text-amber-500'}`}
            onClick={handleSave}
          >
            <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Icon & Title */}
      <div className="p-4 pt-3">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 ${contentTypeColors[file.contentType]}`}>
          {contentTypeIcons[file.contentType]}
        </div>
        
        <h3 className="font-bold text-lg text-foreground mb-2 line-clamp-2 min-h-[3.5rem]">
          {file.title}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4 min-h-[2.5rem]">
          {file.description}
        </p>

        {/* Subject Info */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
          <span className="bg-muted px-2 py-1 rounded-md">{file.subject.name}</span>
          <span className="bg-muted px-2 py-1 rounded-md">المستوى {file.subject.level}</span>
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-muted-foreground pt-4 border-t border-border">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1" title="المشاهدات">
              <Eye className="w-4 h-4" />
              <span>{file.views}</span>
            </div>
            <div className="flex items-center gap-1" title="التحميلات">
              <Download className="w-4 h-4" />
              <span>{file.downloads}</span>
            </div>
          </div>
          <div className="flex items-center gap-1" title="التقييم">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="font-medium">{file.rating}</span>
            <span className="text-xs">({file.ratingsCount})</span>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="p-4 pt-0">
        <Button
          className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 transition-all duration-300"
          onClick={() => onDownload?.(file)}
        >
          <Download className="w-4 h-4 ml-2" />
          تحميل الملف
        </Button>
      </div>

      {/* Hover Overlay */}
      <div 
        className={`absolute inset-0 bg-gradient-to-t from-emerald-600/5 to-transparent pointer-events-none transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
      />
    </div>
  );
}
