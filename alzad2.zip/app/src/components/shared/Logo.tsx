import { BookOpen } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  animated?: boolean;
}

const sizes = {
  sm: { icon: 24, text: 'text-lg' },
  md: { icon: 32, text: 'text-xl' },
  lg: { icon: 48, text: 'text-2xl' },
  xl: { icon: 64, text: 'text-4xl' },
};

export function Logo({ size = 'md', showText = true, animated = false }: LogoProps) {
  const { icon, text } = sizes[size];

  return (
    <div className={`flex items-center gap-2 ${animated ? 'animate-fade-in' : ''}`}>
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl blur-lg opacity-50" />
        <div className="relative bg-gradient-to-br from-emerald-500 to-teal-600 p-2.5 rounded-xl">
          <BookOpen size={icon} className="text-white" strokeWidth={2.5} />
        </div>
      </div>
      {showText && (
        <div className={`flex flex-col ${animated ? 'animate-slide-in-right' : ''}`}>
          <span className={`font-bold ${text} text-gradient leading-tight`}>
            الزاد
          </span>
          <span className="text-[10px] text-muted-foreground -mt-1">
            زاد العلم والتراث
          </span>
        </div>
      )}
    </div>
  );
}
