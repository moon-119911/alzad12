import { useState, useEffect } from 'react';
import { 
  Search, 
  Upload, 
  Bookmark, 
  User, 
  LogOut, 
  Menu,
  X,
  Home,
  FileText,
  ChevronDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Logo } from './Logo';
import { currentUser } from '@/data/mockData';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
  isLoggedIn?: boolean;
}

const navItems = [
  { id: 'home', label: 'الرئيسية', icon: Home },
  { id: 'search', label: 'البحث', icon: Search },
  { id: 'upload', label: 'الرفع', icon: Upload },
  { id: 'saved', label: 'المحفوظات', icon: Bookmark },
];

export function Navbar({ onNavigate, currentPage, isLoggedIn = true }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/90 backdrop-blur-xl shadow-lg border-b border-emerald-100/50'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <div 
            className="cursor-pointer transition-transform hover:scale-105"
            onClick={() => onNavigate('home')}
          >
            <Logo size="md" />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  className={`relative gap-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                    isActive
                      ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                  onClick={() => onNavigate(item.id)}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-medium">{item.label}</span>
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 bg-emerald-500 rounded-full" />
                  )}
                </Button>
              );
            })}
          </nav>

          {/* User Actions */}
          <div className="flex items-center gap-2">
            {isLoggedIn ? (
              <>
                {/* Desktop User Menu */}
                <div className="hidden lg:block">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="gap-2 pl-2 rounded-xl hover:bg-muted">
                        <Avatar className="w-8 h-8 border-2 border-emerald-200">
                          <AvatarImage src={currentUser.avatar} />
                          <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm">
                            {currentUser.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium text-sm">{currentUser.name}</span>
                        <ChevronDown className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <div className="flex items-center gap-3 p-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={currentUser.avatar} />
                          <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                            {currentUser.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{currentUser.name}</p>
                          <p className="text-xs text-muted-foreground">{currentUser.email}</p>
                        </div>
                      </div>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => onNavigate('profile')} className="gap-2">
                        <User className="w-4 h-4" />
                        الملف الشخصي
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onNavigate('my-uploads')} className="gap-2">
                        <FileText className="w-4 h-4" />
                        ملفاتي
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={() => onNavigate('login')} 
                        className="gap-2 text-red-600 focus:text-red-600"
                      >
                        <LogOut className="w-4 h-4" />
                        تسجيل الخروج
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Mobile Menu Button */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                >
                  {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </Button>
              </>
            ) : (
              <Button
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                onClick={() => onNavigate('login')}
              >
                تسجيل الدخول
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`lg:hidden absolute top-full left-0 right-0 bg-white/95 backdrop-blur-xl border-b border-emerald-100/50 shadow-lg transition-all duration-300 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <nav className="flex flex-col p-4 gap-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <Button
                key={item.id}
                variant="ghost"
                className={`justify-start gap-3 rounded-xl ${
                  isActive
                    ? 'text-emerald-700 bg-emerald-50'
                    : 'text-muted-foreground'
                }`}
                onClick={() => {
                  onNavigate(item.id);
                  setIsMobileMenuOpen(false);
                }}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Button>
            );
          })}
          {isLoggedIn && (
            <>
              <div className="border-t border-border my-2" />
              <Button
                variant="ghost"
                className="justify-start gap-3 rounded-xl"
                onClick={() => {
                  onNavigate('profile');
                  setIsMobileMenuOpen(false);
                }}
              >
                <User className="w-5 h-5" />
                الملف الشخصي
              </Button>
              <Button
                variant="ghost"
                className="justify-start gap-3 rounded-xl text-red-600"
                onClick={() => {
                  onNavigate('login');
                  setIsMobileMenuOpen(false);
                }}
              >
                <LogOut className="w-5 h-5" />
                تسجيل الخروج
              </Button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
