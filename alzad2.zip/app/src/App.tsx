import { useState, useEffect } from 'react';
import { Navbar } from '@/components/shared/Navbar';
import { AnimatedBackground } from '@/components/shared/AnimatedBackground';
import { LoginPage } from '@/pages/LoginPage';
import { WelcomePage } from '@/pages/WelcomePage';
import { HomePage } from '@/pages/HomePage';
import { SearchPage } from '@/pages/SearchPage';
import { UploadPage } from '@/pages/UploadPage';
import { SavedFilesPage } from '@/pages/SavedFilesPage';
import { ProfilePage } from '@/pages/ProfilePage';
import './App.css';

type Page = 'login' | 'welcome' | 'home' | 'search' | 'upload' | 'saved' | 'profile' | 'my-uploads' | 'file-details';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleNavigate = (page: string) => {
    if (page === 'login') {
      setIsLoggedIn(false);
    } else if (page === 'welcome') {
      setIsLoggedIn(true);
    } else if (!isLoggedIn && page !== 'login') {
      setCurrentPage('login');
      return;
    }
    setCurrentPage(page as Page);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage onNavigate={handleNavigate} />;
      case 'welcome':
        return <WelcomePage onNavigate={handleNavigate} />;
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'search':
        return <SearchPage />;
      case 'upload':
        return <UploadPage onNavigate={handleNavigate} />;
      case 'saved':
        return <SavedFilesPage onNavigate={handleNavigate} />;
      case 'profile':
      case 'my-uploads':
        return <ProfilePage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  const showNavbar = isLoggedIn && currentPage !== 'welcome' && currentPage !== 'login';

  return (
    <div className={`min-h-screen transition-opacity duration-500 ${mounted ? 'opacity-100' : 'opacity-0'}`}>
      {/* Animated Background - Only show on logged in pages */}
      {showNavbar && <AnimatedBackground />}
      
      {/* Navigation */}
      {showNavbar && (
        <Navbar 
          onNavigate={handleNavigate} 
          currentPage={currentPage}
          isLoggedIn={isLoggedIn}
        />
      )}

      {/* Main Content */}
      <main className="relative z-10">
        {renderPage()}
      </main>
    </div>
  );
}

export default App;
