import { useState, useEffect } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  Users, 
  FileText,
  Sparkles,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/shared/Logo';
import { stats } from '@/data/mockData';

interface LoginPageProps {
  onNavigate: (page: string) => void;
}

export function LoginPage({ onNavigate }: LoginPageProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleGoogleLogin = () => {
    setIsLoading(true);
    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      onNavigate('welcome');
    }, 1500);
  };

  const features = [
    { icon: BookOpen, text: 'شارك ملفاتك الدراسية بسهولة' },
    { icon: GraduationCap, text: 'محتوى متخصص حسب جامعتك وتخصصك' },
    { icon: Users, text: 'تعاون مع زملائك في الدراسة' },
    { icon: FileText, text: 'وصول سريع لملفات المواد' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating Blobs */}
        <div 
          className={`absolute -top-40 -right-40 w-96 h-96 bg-emerald-300/20 rounded-full blur-3xl transition-all duration-1000 ${mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`}
          style={{ animationDelay: '0s' }}
        />
        <div 
          className={`absolute top-1/3 -left-20 w-72 h-72 bg-teal-300/20 rounded-full blur-3xl transition-all duration-1000 delay-300 ${mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`}
        />
        <div 
          className={`absolute -bottom-40 right-1/4 w-80 h-80 bg-amber-300/15 rounded-full blur-3xl transition-all duration-1000 delay-500 ${mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`}
        />
        
        {/* Pattern Grid */}
        <div className="absolute inset-0 pattern-grid opacity-50" />
        
        {/* Floating Icons */}
        <div className="absolute top-20 left-10 text-emerald-200/40 animate-bounce-subtle">
          <BookOpen size={40} />
        </div>
        <div className="absolute top-40 right-20 text-teal-200/40 animate-bounce-subtle" style={{ animationDelay: '1s' }}>
          <GraduationCap size={48} />
        </div>
        <div className="absolute bottom-40 left-20 text-amber-200/40 animate-bounce-subtle" style={{ animationDelay: '2s' }}>
          <FileText size={36} />
        </div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col lg:flex-row">
        {/* Left Side - Content */}
        <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-16 lg:py-0">
          <div 
            className={`max-w-xl mx-auto lg:mx-0 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          >
            {/* Logo */}
            <div className="mb-8">
              <Logo size="lg" animated />
            </div>

            {/* Title */}
            <h1 className="text-3xl lg:text-5xl font-bold text-foreground mb-4 leading-tight">
              منصة <span className="text-gradient">الزاد</span>
              <br />
              <span className="text-2xl lg:text-4xl text-muted-foreground font-medium">
                زاد العلم والتراث
              </span>
            </h1>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              منصة تعليمية متخصصة لمشاركة الملفات الدراسية بين طلاب الجامعات اليمنية. 
              ساهم في إثراء محتوى تخصصك ليكون زاداً لمن يأتي بعدك.
            </p>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
              {features.map((feature, index) => (
                <div 
                  key={index}
                  className={`flex items-center gap-3 p-3 rounded-xl bg-white/60 backdrop-blur-sm border border-emerald-100/50 transition-all duration-500 hover:bg-white hover:shadow-md ${mounted ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}
                  style={{ transitionDelay: `${300 + index * 100}ms` }}
                >
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div 
              className={`flex flex-wrap gap-6 transition-all duration-700 delay-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              <div className="text-center">
                <div className="text-2xl lg:text-3xl font-bold text-emerald-600">{stats.totalUsers.toLocaleString()}+</div>
                <div className="text-sm text-muted-foreground">طالب مسجل</div>
              </div>
              <div className="text-center">
                <div className="text-2xl lg:text-3xl font-bold text-teal-600">{stats.totalFiles.toLocaleString()}+</div>
                <div className="text-sm text-muted-foreground">ملف دراسي</div>
              </div>
              <div className="text-center">
                <div className="text-2xl lg:text-3xl font-bold text-amber-500">{stats.totalDownloads.toLocaleString()}+</div>
                <div className="text-sm text-muted-foreground">تحميل</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Login Card */}
        <div className="flex-1 flex items-center justify-center px-6 py-12 lg:px-16">
          <div 
            className={`w-full max-w-md transition-all duration-700 delay-500 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          >
            <div className="relative">
              {/* Card Glow */}
              <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500 rounded-3xl blur-lg opacity-30 animate-pulse-soft" />
              
              <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/50 p-8">
                {/* Sparkle Badge */}
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-gradient-to-r from-amber-400 to-amber-500 text-white text-xs font-bold px-4 py-1.5 rounded-full flex items-center gap-1 shadow-lg">
                    <Sparkles className="w-3.5 h-3.5" />
                    مجاني 100%
                  </div>
                </div>

                <div className="text-center mb-8 pt-4">
                  <h2 className="text-2xl font-bold text-foreground mb-2">تسجيل الدخول</h2>
                  <p className="text-muted-foreground">سجل دخولك باستخدام حساب Google</p>
                </div>

                {/* Google Login Button */}
                <Button
                  size="lg"
                  className="w-full bg-white hover:bg-gray-50 text-gray-700 border-2 border-gray-200 hover:border-gray-300 rounded-xl h-14 text-base font-medium transition-all duration-300 group"
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin" />
                      جاري تسجيل الدخول...
                    </div>
                  ) : (
                    <>
                      <svg className="w-5 h-5 ml-2" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        />
                      </svg>
                      <span>الدخول بحساب Google</span>
                      <ArrowRight className="w-4 h-4 mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                    </>
                  )}
                </Button>

                {/* Divider */}
                <div className="relative my-8">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-200" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-white text-muted-foreground">أو</span>
                  </div>
                </div>

                {/* Benefits */}
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    <span>وصول فوري لآلاف الملفات الدراسية</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    <span>محتوى منظم حسب جامعتك وتخصصك</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    <span>شارك معرفتك مع زملائك</span>
                  </div>
                </div>

                {/* Terms */}
                <p className="text-xs text-center text-muted-foreground mt-8">
                  بتسجيل الدخول، أنت توافق على{' '}
                  <a href="#" className="text-emerald-600 hover:underline">شروط الاستخدام</a>
                  {' '}و{' '}
                  <a href="#" className="text-emerald-600 hover:underline">سياسة الخصوصية</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
