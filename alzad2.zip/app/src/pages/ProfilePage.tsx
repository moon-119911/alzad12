import { useState, useEffect, useRef } from 'react';
import { 
  Building2, 
  GraduationCap, 
  BarChart3, 
  Calendar,
  FileText,
  Download,
  Star,
  Edit2,
  Camera,
  CheckCircle2,
  TrendingUp,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { currentUser, universities, majors, studyFiles } from '@/data/mockData';

interface ProfilePageProps {
  onNavigate: (page: string) => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const [mounted, setMounted] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [user, setUser] = useState(currentUser);
  const [editedUser, setEditedUser] = useState(currentUser);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSave = () => {
    setUser(editedUser);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedUser(user);
    setIsEditing(false);
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, upload the file and get the URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditedUser({ ...editedUser, avatar: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const userFiles = studyFiles.filter(f => f.uploader.id === user.id);
  const university = universities.find(u => u.id === user.university);
  const major = majors.find(m => m.id === user.major);

  const stats = [
    { icon: FileText, label: 'الملفات المرفوعة', value: user.uploadsCount, color: 'from-emerald-500 to-teal-600' },
    { icon: Download, label: 'إجمالي التحميلات', value: user.downloadsCount, color: 'from-blue-500 to-blue-600' },
    { icon: Star, label: 'متوسط التقييم', value: '4.7', color: 'from-amber-500 to-orange-600' },
    { icon: TrendingUp, label: 'المشاهدات', value: '1.2K', color: 'from-purple-500 to-purple-600' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/50 pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header Card */}
        <div 
          className={`relative bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden mb-8 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          {/* Cover */}
          <div className="h-32 lg:h-48 bg-gradient-to-r from-emerald-500 via-teal-500 to-teal-600" />
          
          {/* Profile Info */}
          <div className="relative px-6 pb-6">
            {/* Avatar */}
            <div className="relative -mt-16 mb-4">
              <div className="relative inline-block">
                <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
                  <AvatarImage src={isEditing ? editedUser.avatar : user.avatar} />
                  <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-3xl">
                    {user.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                {isEditing && (
                  <button
                    onClick={handleAvatarClick}
                    className="absolute bottom-0 right-0 w-10 h-10 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-emerald-600 transition-colors"
                  >
                    <Camera className="w-5 h-5" />
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={handleFileChange}
                />
              </div>
            </div>

            {/* Name & Actions */}
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-3 max-w-md">
                    <Input
                      value={editedUser.name}
                      onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                      className="text-lg font-bold"
                      placeholder="الاسم"
                    />
                    <Textarea
                      value={editedUser.bio || ''}
                      onChange={(e) => setEditedUser({ ...editedUser, bio: e.target.value })}
                      placeholder="نبذة عنك..."
                      rows={2}
                    />
                  </div>
                ) : (
                  <>
                    <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">{user.name}</h1>
                    <p className="text-muted-foreground max-w-lg">{user.bio || 'لا توجد نبذة'}</p>
                  </>
                )}

                {/* Badges */}
                <div className="flex flex-wrap items-center gap-2 mt-4">
                  <Badge variant="secondary" className="gap-1">
                    <Building2 className="w-3 h-3" />
                    {university?.name}
                  </Badge>
                  <Badge variant="secondary" className="gap-1">
                    <GraduationCap className="w-3 h-3" />
                    {major?.name}
                  </Badge>
                  <Badge variant="secondary" className="gap-1">
                    <BarChart3 className="w-3 h-3" />
                    المستوى {user.level}
                  </Badge>
                  <Badge variant="outline" className="gap-1 text-emerald-600 border-emerald-200">
                    <Calendar className="w-3 h-3" />
                    انضم {new Date(user.joinedAt).toLocaleDateString('ar-YE')}
                  </Badge>
                </div>
              </div>

              {/* Edit Actions */}
              <div className="flex items-center gap-2">
                {isEditing ? (
                  <>
                    <Button variant="outline" onClick={handleCancel}>
                      إلغاء
                    </Button>
                    <Button 
                      className="bg-gradient-to-r from-emerald-600 to-teal-600"
                      onClick={handleSave}
                    >
                      <CheckCircle2 className="w-4 h-4 ml-2" />
                      حفظ
                    </Button>
                  </>
                ) : (
                  <Button variant="outline" onClick={() => setIsEditing(true)}>
                    <Edit2 className="w-4 h-4 ml-2" />
                    تعديل الملف
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div 
          className={`grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8 transition-all duration-700 delay-100 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          {stats.map((stat, index) => (
            <Card key={index} className="border-0 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Uploads */}
        <div 
          className={`transition-all duration-700 delay-200 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-foreground">آخر الملفات المرفوعة</h2>
              <p className="text-sm text-muted-foreground">الملفات التي قمت برفعها مؤخراً</p>
            </div>
            <Button variant="outline" onClick={() => onNavigate('my-uploads')}>
              عرض الكل
            </Button>
          </div>

          {userFiles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {userFiles.slice(0, 4).map((file, index) => (
                <div 
                  key={file.id}
                  className={`bg-white rounded-xl p-4 border border-gray-100 hover:shadow-md transition-all duration-300 cursor-pointer ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                  style={{ transitionDelay: `${300 + index * 100}ms` }}
                  onClick={() => onNavigate('file-details')}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
                      <FileText className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground truncate">{file.title}</h3>
                      <p className="text-sm text-muted-foreground truncate">{file.subject.name}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Download className="w-3 h-3" />
                          {file.downloads}
                        </span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          {file.rating}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-gray-200">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-muted-foreground">لم تقم برفع أي ملفات بعد</p>
              <Button 
                className="mt-4 bg-gradient-to-r from-emerald-600 to-teal-600"
                onClick={() => onNavigate('upload')}
              >
                ارفع ملفاً الآن
              </Button>
            </div>
          )}
        </div>

        {/* Achievement Card */}
        <div 
          className={`mt-8 transition-all duration-700 delay-300 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-amber-800">مُساهم نشط</h3>
                  <p className="text-amber-700">لقد ساهمت بـ {user.uploadsCount} ملف و ساعدت {user.downloadsCount} طالباً في تعلمهم</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
