import { useState, useEffect } from 'react';
import { Bookmark, FolderOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FileCard } from '@/components/shared/FileCard';
import { studyFiles } from '@/data/mockData';

interface SavedFilesPageProps {
  onNavigate: (page: string) => void;
}

export function SavedFilesPage({ onNavigate }: SavedFilesPageProps) {
  const [mounted, setMounted] = useState(false);
  const [savedFiles, setSavedFiles] = useState(studyFiles.slice(0, 4).map(f => ({ ...f, isSaved: true })));

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleUnsave = (fileId: string) => {
    setSavedFiles(savedFiles.filter(f => f.id !== fileId));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div 
          className={`mb-8 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-500 flex items-center justify-center">
              <Bookmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-foreground">المحفوظات</h1>
              <p className="text-muted-foreground">الملفات التي قمت بحفظها للوصول إليها لاحقاً</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div 
          className={`grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 transition-all duration-700 delay-100 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-emerald-600">{savedFiles.length}</div>
            <div className="text-sm text-muted-foreground">ملف محفوظ</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-blue-600">
              {savedFiles.filter(f => f.contentType === 'lecture').length}
            </div>
            <div className="text-sm text-muted-foreground">ملزمة</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-amber-600">
              {savedFiles.filter(f => f.contentType === 'summary').length}
            </div>
            <div className="text-sm text-muted-foreground">ملخص</div>
          </div>
        </div>

        {/* Files Grid */}
        {savedFiles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedFiles.map((file, index) => (
              <div 
                key={file.id}
                className={`transition-all duration-500 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${200 + index * 100}ms` }}
              >
                <FileCard 
                  file={file} 
                  onSave={() => handleUnsave(file.id)}
                />
              </div>
            ))}
          </div>
        ) : (
          <div 
            className={`text-center py-16 transition-all duration-700 delay-200 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          >
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
              <FolderOpen className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">لا توجد ملفات محفوظة</h3>
            <p className="text-muted-foreground mb-6">ابدأ بحفظ الملفات المفيدة للوصول إليها بسهولة</p>
            <Button 
              className="bg-gradient-to-r from-emerald-600 to-teal-600"
              onClick={() => onNavigate('search')}
            >
              استكشف الملفات
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
