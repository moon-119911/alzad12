import { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  File, 
  X, 
  CheckCircle2, 
  AlertCircle,
  BookOpen,
  BookMarked,
  FileText,
  ClipboardList,
  Sparkles,
  ArrowLeft,
  FileType,
  FileUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { subjects, academicYears, contentTypeLabels } from '@/data/mockData';
import type { ContentType } from '@/types';

interface UploadPageProps {
  onNavigate: (page: string) => void;
}

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const ALLOWED_TYPES = ['.pdf', '.doc', '.docx', '.ppt', '.pptx', '.jpg', '.jpeg', '.png'];

const contentTypeIcons: Record<ContentType, React.ReactNode> = {
  lecture: <BookOpen className="w-6 h-6" />,
  book: <BookMarked className="w-6 h-6" />,
  summary: <FileText className="w-6 h-6" />,
  exam: <ClipboardList className="w-6 h-6" />,
};

export function UploadPage({ onNavigate }: UploadPageProps) {
  const [mounted, setMounted] = useState(false);
  const [step, setStep] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    contentType: '' as ContentType | '',
    subject: '',
    academicYear: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const validateFile = (file: File): string | null => {
    if (file.size > MAX_FILE_SIZE) {
      return 'حجم الملف يتجاوز 50 ميجابايت';
    }
    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!ALLOWED_TYPES.includes(ext)) {
      return 'نوع الملف غير مدعوم';
    }
    return null;
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      const error = validateFile(file);
      if (error) {
        setErrors({ file: error });
        return;
      }
      setUploadedFile(file);
      setErrors({});
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const error = validateFile(file);
      if (error) {
        setErrors({ file: error });
        return;
      }
      setUploadedFile(file);
      setErrors({});
    }
  };

  const handleUpload = async () => {
    if (!uploadedFile) return;
    
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          setStep(2);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'عنوان الملف مطلوب';
    }
    if (!formData.contentType) {
      newErrors.contentType = 'نوع المحتوى مطلوب';
    }
    if (!formData.subject) {
      newErrors.subject = 'المادة مطلوبة';
    }
    if (!formData.academicYear) {
      newErrors.academicYear = 'العام الدراسي مطلوب';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateStep2()) return;
    
    // Simulate submission
    setIsComplete(true);
    setTimeout(() => {
      onNavigate('home');
    }, 2000);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    if (ext === 'pdf') return <FileType className="w-8 h-8 text-red-500" />;
    if (['doc', 'docx'].includes(ext || '')) return <FileType className="w-8 h-8 text-blue-500" />;
    if (['ppt', 'pptx'].includes(ext || '')) return <FileType className="w-8 h-8 text-orange-500" />;
    if (['jpg', 'jpeg', 'png'].includes(ext || '')) return <FileType className="w-8 h-8 text-purple-500" />;
    return <File className="w-8 h-8 text-gray-500" />;
  };

  if (isComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-center justify-center p-6">
        <div 
          className={`text-center transition-all duration-500 ${mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}
        >
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center animate-bounce-subtle">
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">تم رفع الملف بنجاح!</h2>
          <p className="text-muted-foreground mb-6">شكراً لمشاركتك المعرفة مع زملائك</p>
          <div className="flex items-center justify-center gap-3">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/50 pt-20 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div 
          className={`mb-8 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <Button
            variant="ghost"
            className="mb-4"
            onClick={() => step === 1 ? onNavigate('home') : setStep(1)}
          >
            <ArrowLeft className="w-4 h-4 ml-2" />
            رجوع
          </Button>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">رفع ملف جديد</h1>
          <p className="text-muted-foreground">شارك ملفاتك الدراسية مع زملائك</p>
        </div>

        {/* Progress Steps */}
        <div 
          className={`flex items-center justify-center gap-4 mb-8 transition-all duration-700 delay-100 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          {[
            { num: 1, label: 'رفع الملف' },
            { num: 2, label: 'تفاصيل الملف' },
          ].map((s, index) => (
            <div key={s.num} className="flex items-center">
              <div className="flex flex-col items-center">
                <div 
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                    step >= s.num
                      ? 'bg-emerald-500 text-white'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {s.num}
                </div>
                <span className={`text-xs mt-1 ${step >= s.num ? 'text-emerald-600' : 'text-gray-400'}`}>
                  {s.label}
                </span>
              </div>
              {index < 1 && (
                <div className={`w-24 h-0.5 mx-2 ${step > 1 ? 'bg-emerald-500' : 'bg-gray-200'}`} />
              )}
            </div>
          ))}
        </div>

        {/* Step 1: File Upload */}
        {step === 1 && (
          <div 
            className={`bg-white rounded-3xl shadow-lg border border-gray-100 p-8 transition-all duration-700 delay-200 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          >
            {!uploadedFile ? (
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`relative border-3 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300 ${
                  isDragging
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-gray-300 hover:border-emerald-400 hover:bg-gray-50'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={handleFileSelect}
                  accept={ALLOWED_TYPES.join(',')}
                />
                
                <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-emerald-100 to-teal-100 flex items-center justify-center">
                  <Upload className="w-10 h-10 text-emerald-600" />
                </div>
                
                <h3 className="text-xl font-bold text-foreground mb-2">
                  اسحب الملف هنا أو انقر للاختيار
                </h3>
                <p className="text-muted-foreground mb-4">
                  يدعم الملفات بصيغ PDF, Word, PowerPoint, والصور
                </p>
                
                <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <FileType className="w-4 h-4" />
                    PDF, DOC, PPT
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <FileUp className="w-4 h-4" />
                    حتى 50 ميجابايت
                  </span>
                </div>

                {errors.file && (
                  <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-xl flex items-center gap-2">
                    <AlertCircle className="w-5 h-5" />
                    {errors.file}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-6">
                {/* File Preview */}
                <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                  {getFileIcon(uploadedFile.name)}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{uploadedFile.name}</p>
                    <p className="text-sm text-muted-foreground">{formatFileSize(uploadedFile.size)}</p>
                  </div>
                  {!isUploading && (
                    <button
                      onClick={() => setUploadedFile(null)}
                      className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
                    >
                      <X className="w-5 h-5 text-gray-500" />
                    </button>
                  )}
                </div>

                {/* Upload Progress */}
                {isUploading && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">جاري الرفع...</span>
                      <span className="font-medium text-emerald-600">{uploadProgress}%</span>
                    </div>
                    <Progress value={uploadProgress} className="h-2" />
                  </div>
                )}

                {/* Upload Button */}
                {!isUploading && (
                  <Button
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 h-12 text-base"
                    onClick={handleUpload}
                  >
                    <Upload className="w-5 h-5 ml-2" />
                    رفع الملف
                  </Button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Step 2: File Details */}
        {step === 2 && (
          <div 
            className={`bg-white rounded-3xl shadow-lg border border-gray-100 p-8 transition-all duration-500`}
          >
            <div className="space-y-6">
              {/* Title */}
              <div>
                <Label className="text-base mb-2 block">عنوان الملف *</Label>
                <Input
                  placeholder="مثال: ملزمة برمجة 1 - الفصل الأول"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className={`h-12 ${errors.title ? 'border-red-500' : ''}`}
                />
                {errors.title && (
                  <p className="text-red-500 text-sm mt-1">{errors.title}</p>
                )}
              </div>

              {/* Description */}
              <div>
                <Label className="text-base mb-2 block">وصف الملف</Label>
                <Textarea
                  placeholder="أضف وصفاً مختصراً للملف..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                />
              </div>

              {/* Content Type */}
              <div>
                <Label className="text-base mb-3 block">نوع المحتوى *</Label>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  {(['lecture', 'book', 'summary', 'exam'] as const).map((type) => (
                    <button
                      key={type}
                      onClick={() => setFormData({ ...formData, contentType: type })}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-300 ${
                        formData.contentType === type
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                          : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className={`${formData.contentType === type ? 'text-emerald-600' : 'text-gray-500'}`}>
                        {contentTypeIcons[type]}
                      </div>
                      <span className="text-sm font-medium">{contentTypeLabels[type]}</span>
                    </button>
                  ))}
                </div>
                {errors.contentType && (
                  <p className="text-red-500 text-sm mt-2">{errors.contentType}</p>
                )}
              </div>

              {/* Subject & Academic Year */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <Label className="text-base mb-2 block">المادة *</Label>
                  <Select 
                    value={formData.subject} 
                    onValueChange={(value) => setFormData({ ...formData, subject: value })}
                  >
                    <SelectTrigger className={`h-12 ${errors.subject ? 'border-red-500' : ''}`}>
                      <SelectValue placeholder="اختر المادة" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.name} ({subject.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.subject && (
                    <p className="text-red-500 text-sm mt-1">{errors.subject}</p>
                  )}
                </div>

                <div>
                  <Label className="text-base mb-2 block">العام الدراسي *</Label>
                  <Select 
                    value={formData.academicYear} 
                    onValueChange={(value) => setFormData({ ...formData, academicYear: value })}
                  >
                    <SelectTrigger className={`h-12 ${errors.academicYear ? 'border-red-500' : ''}`}>
                      <SelectValue placeholder="اختر العام الدراسي" />
                    </SelectTrigger>
                    <SelectContent>
                      {academicYears.map((year) => (
                        <SelectItem key={year} value={year}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.academicYear && (
                    <p className="text-red-500 text-sm mt-1">{errors.academicYear}</p>
                  )}
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-6 border-t border-gray-100">
                <Button
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 h-14 text-base"
                  onClick={handleSubmit}
                >
                  <Sparkles className="w-5 h-5 ml-2" />
                  نشر الملف
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Info Card */}
        <div 
          className={`mt-8 bg-emerald-50 rounded-2xl p-6 transition-all duration-700 delay-300 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h4 className="font-bold text-emerald-800 mb-1">نصائح لرفع ملف ناجح</h4>
              <ul className="text-sm text-emerald-700 space-y-1">
                <li>• اختر عنواناً واضحاً ي describe محتوى الملف</li>
                <li>• أضف وصفاً مختصراً يساعد الآخرين على فهم المحتوى</li>
                <li>• تأكد من اختيار المادة والعام الدراسي الصحيحين</li>
                <li>• تأكد من أن الملف خالٍ من الأخطاء قبل الرفع</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
