import { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  GraduationCap, 
  Building2, 
  BarChart3,
  Sparkles,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Logo } from '@/components/shared/Logo';
import { universities, majors, levels } from '@/data/mockData';

interface WelcomePageProps {
  onNavigate: (page: string) => void;
}

export function WelcomePage({ onNavigate }: WelcomePageProps) {
  const [step, setStep] = useState(1);
  const [isAnimating, setIsAnimating] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [formData, setFormData] = useState({
    university: '',
    major: '',
    level: '',
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleNext = () => {
    if (step < 3) {
      setIsAnimating(true);
      setTimeout(() => {
        setStep(step + 1);
        setIsAnimating(false);
      }, 300);
    } else {
      onNavigate('home');
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setIsAnimating(true);
      setTimeout(() => {
        setStep(step - 1);
        setIsAnimating(false);
      }, 300);
    }
  };

  const canProceed = () => {
    if (step === 1) return formData.university !== '';
    if (step === 2) return formData.major !== '';
    if (step === 3) return formData.level !== '';
    return false;
  };

  const steps = [
    { 
      icon: Building2, 
      title: 'اختر جامعتك', 
      description: 'حدد الجامعة التي تدرس فيها',
      color: 'from-blue-500 to-blue-600'
    },
    { 
      icon: GraduationCap, 
      title: 'اختر تخصصك', 
      description: 'حدد تخصصك الدراسي',
      color: 'from-emerald-500 to-teal-600'
    },
    { 
      icon: BarChart3, 
      title: 'اختر مستواك', 
      description: 'حدد مستواك الدراسي الحالي',
      color: 'from-amber-500 to-orange-600'
    },
  ];

  const CurrentIcon = steps[step - 1].icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-300/15 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -right-40 w-80 h-80 bg-teal-300/15 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-72 h-72 bg-amber-300/10 rounded-full blur-3xl" />
        <div className="absolute inset-0 pattern-dots opacity-30" />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="p-6">
          <Logo size="md" />
        </header>

        {/* Main Content */}
        <main className="flex-1 flex items-center justify-center px-6 py-12">
          <div className="w-full max-w-2xl">
            {/* Progress Steps */}
            <div 
              className={`flex items-center justify-center gap-4 mb-12 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              {steps.map((s, index) => {
                const StepIcon = s.icon;
                const isActive = step === index + 1;
                const isCompleted = step > index + 1;
                
                return (
                  <div key={index} className="flex items-center">
                    <div 
                      className={`flex flex-col items-center transition-all duration-300 ${
                        isActive ? 'scale-110' : isCompleted ? 'scale-100' : 'scale-95 opacity-50'
                      }`}
                    >
                      <div 
                        className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 ${
                          isActive
                            ? `bg-gradient-to-br ${s.color} shadow-lg shadow-emerald-500/30`
                            : isCompleted
                            ? 'bg-emerald-500 text-white'
                            : 'bg-gray-200 text-gray-400'
                        }`}
                      >
                        {isCompleted ? (
                          <CheckCircle2 className="w-7 h-7" />
                        ) : (
                          <StepIcon className="w-7 h-7 text-white" />
                        )}
                      </div>
                      <span className={`text-xs mt-2 font-medium ${isActive ? 'text-foreground' : 'text-muted-foreground'}`}>
                        {s.title}
                      </span>
                    </div>
                    {index < steps.length - 1 && (
                      <div className={`w-16 h-0.5 mx-2 transition-all duration-500 ${
                        step > index + 1 ? 'bg-emerald-500' : 'bg-gray-200'
                      }`} />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Card */}
            <div 
              className={`relative transition-all duration-700 delay-200 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500 rounded-3xl blur-lg opacity-20" />
              
              <div className="relative bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/50 p-8">
                {/* Welcome Badge */}
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-xs font-bold px-4 py-1.5 rounded-full flex items-center gap-1 shadow-lg">
                    <Sparkles className="w-3.5 h-3.5" />
                    مرحباً بك في الزاد
                  </div>
                </div>

                <div className={`transition-all duration-300 ${isAnimating ? 'opacity-0 translate-x-10' : 'opacity-100 translate-x-0'}`}>
                  {/* Step Header */}
                  <div className="text-center mb-8 pt-4">
                    <div className={`w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br ${steps[step-1].color} flex items-center justify-center mb-4 shadow-lg`}>
                      <CurrentIcon className="w-10 h-10 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-foreground mb-2">{steps[step-1].title}</h2>
                    <p className="text-muted-foreground">{steps[step-1].description}</p>
                  </div>

                  {/* Step Content */}
                  <div className="space-y-6">
                    {step === 1 && (
                      <div className="space-y-4">
                        <Label className="text-base">الجامعة</Label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {universities.map((uni) => (
                            <button
                              key={uni.id}
                              onClick={() => setFormData({ ...formData, university: uni.id })}
                              className={`p-4 rounded-xl border-2 text-right transition-all duration-300 ${
                                formData.university === uni.id
                                  ? 'border-emerald-500 bg-emerald-50 shadow-md'
                                  : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50'
                              }`}
                            >
                              <div className="font-medium text-foreground">{uni.name}</div>
                              <div className="text-xs text-muted-foreground mt-1">{uni.description}</div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {step === 2 && (
                      <div className="space-y-4">
                        <Label className="text-base">التخصص</Label>
                        <Select 
                          value={formData.major} 
                          onValueChange={(value) => setFormData({ ...formData, major: value })}
                        >
                          <SelectTrigger className="h-14 text-base">
                            <SelectValue placeholder="اختر تخصصك" />
                          </SelectTrigger>
                          <SelectContent>
                            {majors
                              .filter((m) => m.universityId === formData.university)
                              .map((major) => (
                                <SelectItem key={major.id} value={major.id}>
                                  {major.name}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {step === 3 && (
                      <div className="space-y-4">
                        <Label className="text-base">المستوى الدراسي</Label>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {levels.map((level) => (
                            <button
                              key={level.value}
                              onClick={() => setFormData({ ...formData, level: level.value.toString() })}
                              className={`p-4 rounded-xl border-2 text-center transition-all duration-300 ${
                                formData.level === level.value.toString()
                                  ? 'border-emerald-500 bg-emerald-50 shadow-md'
                                  : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50'
                              }`}
                            >
                              <div className="font-medium text-foreground">{level.label}</div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
                  <Button
                    variant="outline"
                    onClick={handleBack}
                    disabled={step === 1}
                    className="gap-2"
                  >
                    <ChevronRight className="w-4 h-4" />
                    السابق
                  </Button>
                  
                  <Button
                    onClick={handleNext}
                    disabled={!canProceed()}
                    className={`gap-2 bg-gradient-to-r ${steps[step-1].color} text-white`}
                  >
                    {step === 3 ? 'إكمال التسجيل' : 'التالي'}
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Skip Option */}
            <div className="text-center mt-6">
              <button 
                onClick={() => onNavigate('home')}
                className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors flex items-center gap-1 mx-auto"
              >
                تخطي هذه الخطوة
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
