import { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Download, 
  ChevronLeft,
  Sparkles,
  FileText,
  BookOpen,
  BookMarked,
  ClipboardList,
  ArrowUpRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FileCard } from '@/components/shared/FileCard';
import { studyFiles, stats, contentTypeColors } from '@/data/mockData';
import type { ContentType } from '@/types';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

const contentTypeIcons: Record<ContentType, React.ReactNode> = {
  lecture: <BookOpen className="w-5 h-5" />,
  book: <BookMarked className="w-5 h-5" />,
  summary: <FileText className="w-5 h-5" />,
  exam: <ClipboardList className="w-5 h-5" />,
};

export function HomePage({ onNavigate }: HomePageProps) {
  const [mounted, setMounted] = useState(false);
  const [activeTab, setActiveTab] = useState<'latest' | 'popular'>('latest');

  useEffect(() => {
    setMounted(true);
  }, []);

  const latestFiles = [...studyFiles].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).slice(0, 6);

  const popularFiles = [...studyFiles].sort((a, b) => b.downloads - a.downloads).slice(0, 6);

  const contentTypeStats = [
    { type: 'lecture' as ContentType, count: 1250, label: 'ملزمة' },
    { type: 'book' as ContentType, count: 680, label: 'كتاب' },
    { type: 'summary' as ContentType, count: 920, label: 'ملخص' },
    { type: 'exam' as ContentType, count: 606, label: 'نموذج اختبار' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/50">
      {/* Hero Section */}
      <section className="relative pt-24 pb-16 lg:pt-32 lg:pb-24 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-[600px] h-[600px] bg-emerald-300/15 rounded-full blur-3xl" />
          <div className="absolute top-1/2 -left-40 w-[500px] h-[500px] bg-teal-300/15 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 right-1/4 w-[400px] h-[400px] bg-amber-300/10 rounded-full blur-3xl" />
          <div className="absolute inset-0 pattern-grid opacity-40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            {/* Welcome Badge */}
            <div 
              className={`inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm border border-emerald-200/50 rounded-full px-4 py-2 mb-6 shadow-sm transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span className="text-sm font-medium text-emerald-700">مرحباً بك في الزاد</span>
            </div>

            {/* Title */}
            <h1 
              className={`text-3xl lg:text-5xl font-bold text-foreground mb-6 leading-tight transition-all duration-700 delay-100 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              اكتشف <span className="text-gradient">ملفاتك الدراسية</span>
              <br />
              <span className="text-2xl lg:text-4xl text-muted-foreground font-medium">
                في مكان واحد
              </span>
            </h1>

            {/* Description */}
            <p 
              className={`text-lg text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed transition-all duration-700 delay-200 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              منصة الزاد توفر لك وصولاً سهلاً لجميع الملفات الدراسية الخاصة بتخصصك وجامعتك.
              شارك معرفتك واستفد من تجربة زملائك.
            </p>

            {/* CTA Buttons */}
            <div 
              className={`flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 transition-all duration-700 delay-300 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white px-8 h-14 text-base rounded-xl shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-emerald-500/40 transition-all duration-300 hover:-translate-y-0.5"
                onClick={() => onNavigate('search')}
              >
                <BookOpen className="w-5 h-5 ml-2" />
                استكشف الملفات
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-emerald-200 hover:bg-emerald-50 text-emerald-700 px-8 h-14 text-base rounded-xl transition-all duration-300"
                onClick={() => onNavigate('upload')}
              >
                <TrendingUp className="w-5 h-5 ml-2" />
                ارفع ملفاً
              </Button>
            </div>

            {/* Stats Cards */}
            <div 
              className={`grid grid-cols-2 lg:grid-cols-4 gap-4 transition-all duration-700 delay-400 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            >
              {[
                { icon: TrendingUp, value: stats.totalUsers, label: 'طالب مسجل', color: 'from-emerald-500 to-teal-600' },
                { icon: FileText, value: stats.totalFiles, label: 'ملف دراسي', color: 'from-blue-500 to-blue-600' },
                { icon: Download, value: stats.totalDownloads, label: 'تحميل', color: 'from-amber-500 to-orange-600' },
                { icon: BookOpen, value: stats.totalUniversities, label: 'جامعة', color: 'from-purple-500 to-purple-600' },
              ].map((stat, index) => (
                <Card 
                  key={index} 
                  className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
                >
                  <CardContent className="p-4">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3 mx-auto group-hover:scale-110 transition-transform`}>
                      <stat.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">{stat.value.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Content Types Section */}
      <section className="py-12 bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {contentTypeStats.map((item, index) => (
              <div 
                key={item.type}
                className={`bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${500 + index * 100}ms` }}
                onClick={() => onNavigate('search')}
              >
                <div className={`w-12 h-12 rounded-xl ${contentTypeColors[item.type]} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  {contentTypeIcons[item.type]}
                </div>
                <div className="text-2xl font-bold text-foreground mb-1">{item.count.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">{item.label}</div>
                <div className="flex items-center gap-1 text-emerald-600 text-sm mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>عرض الكل</span>
                  <ChevronLeft className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Files Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-1">أحدث الملفات</h2>
              <p className="text-muted-foreground">تصفح أحدث الملفات المضافة في تخصصك</p>
            </div>
            
            {/* Tabs */}
            <div className="flex items-center gap-2 bg-white p-1 rounded-xl border border-gray-200 shadow-sm">
              <button
                onClick={() => setActiveTab('latest')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  activeTab === 'latest'
                    ? 'bg-emerald-500 text-white shadow-md'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                الأحدث
              </button>
              <button
                onClick={() => setActiveTab('popular')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  activeTab === 'popular'
                    ? 'bg-emerald-500 text-white shadow-md'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                الأكثر تحميلاً
              </button>
            </div>
          </div>

          {/* Files Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(activeTab === 'latest' ? latestFiles : popularFiles).map((file, index) => (
              <div 
                key={file.id}
                className={`transition-all duration-500 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${600 + index * 100}ms` }}
              >
                <FileCard file={file} />
              </div>
            ))}
          </div>

          {/* View All Button */}
          <div className="text-center mt-10">
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-emerald-200 hover:bg-emerald-50 text-emerald-700 px-8 rounded-xl group"
              onClick={() => onNavigate('search')}
            >
              عرض جميع الملفات
              <ArrowUpRight className="w-4 h-4 mr-2 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            className={`relative bg-gradient-to-br from-emerald-600 via-teal-600 to-teal-700 rounded-3xl p-8 lg:p-12 overflow-hidden transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            style={{ transitionDelay: '800ms' }}
          >
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0 pattern-dots" />
            </div>
            
            {/* Floating Elements */}
            <div className="absolute top-10 right-10 w-20 h-20 bg-white/10 rounded-full blur-xl" />
            <div className="absolute bottom-10 left-10 w-32 h-32 bg-white/10 rounded-full blur-xl" />

            <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="text-center lg:text-right">
                <h2 className="text-2xl lg:text-3xl font-bold text-white mb-3">
                  ساهم في بناء تراث تخصصك
                </h2>
                <p className="text-emerald-100 text-lg max-w-xl">
                  ارفع ملفاتك الدراسية وساعد زملائك في التعلم. كل ملف ترفعه يكون زاداً لمن يأتي بعدك.
                </p>
              </div>
              <Button
                size="lg"
                className="bg-white text-emerald-700 hover:bg-emerald-50 px-8 h-14 text-base rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5 whitespace-nowrap"
                onClick={() => onNavigate('upload')}
              >
                <TrendingUp className="w-5 h-5 ml-2" />
                ارفع ملفاً الآن
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
