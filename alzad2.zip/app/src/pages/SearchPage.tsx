import { useState, useEffect } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  Grid3X3, 
  List,
  X,
  Filter,
  BookOpen,
  BookMarked,
  FileText,
  ClipboardList
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { FileCard } from '@/components/shared/FileCard';
import { studyFiles, subjects, academicYears, levels, contentTypeLabels } from '@/data/mockData';
import type { ContentType } from '@/types';

const contentTypeIcons: Record<ContentType, React.ReactNode> = {
  lecture: <BookOpen className="w-4 h-4" />,
  book: <BookMarked className="w-4 h-4" />,
  summary: <FileText className="w-4 h-4" />,
  exam: <ClipboardList className="w-4 h-4" />,
};

const sortOptions = [
  { value: 'newest', label: 'الأحدث' },
  { value: 'most-downloaded', label: 'الأكثر تحميلاً' },
  { value: 'most-viewed', label: 'الأكثر مشاهدة' },
  { value: 'highest-rated', label: 'الأعلى تقييماً' },
];

export function SearchPage() {
  const [mounted, setMounted] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    contentType: 'all' as ContentType | 'all',
    subject: 'all',
    level: 'all',
    academicYear: 'all',
    sortBy: 'newest',
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Filter and sort files
  const filteredFiles = studyFiles.filter((file) => {
    const matchesSearch = 
      searchQuery === '' || 
      file.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.subject.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = filters.contentType === 'all' || file.contentType === filters.contentType;
    const matchesSubject = filters.subject === 'all' || file.subject.id === filters.subject;
    const matchesLevel = filters.level === 'all' || file.subject.level.toString() === filters.level;
    const matchesYear = filters.academicYear === 'all' || file.academicYear === filters.academicYear;

    return matchesSearch && matchesType && matchesSubject && matchesLevel && matchesYear;
  }).sort((a, b) => {
    switch (filters.sortBy) {
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'most-downloaded':
        return b.downloads - a.downloads;
      case 'most-viewed':
        return b.views - a.views;
      case 'highest-rated':
        return b.rating - a.rating;
      default:
        return 0;
    }
  });

  const activeFiltersCount = [
    filters.contentType !== 'all',
    filters.subject !== 'all',
    filters.level !== 'all',
    filters.academicYear !== 'all',
  ].filter(Boolean).length;

  const clearFilters = () => {
    setFilters({
      contentType: 'all',
      subject: 'all',
      level: 'all',
      academicYear: 'all',
      sortBy: 'newest',
    });
    setSearchQuery('');
  };

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Content Type */}
      <div>
        <label className="text-sm font-medium mb-3 block">نوع المحتوى</label>
        <div className="grid grid-cols-2 gap-2">
          {(['all', 'lecture', 'book', 'summary', 'exam'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilters({ ...filters, contentType: type })}
              className={`flex items-center gap-2 p-3 rounded-xl border-2 text-sm transition-all duration-300 ${
                filters.contentType === type
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                  : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50'
              }`}
            >
              {type === 'all' ? (
                <Filter className="w-4 h-4" />
              ) : (
                contentTypeIcons[type]
              )}
              <span>{type === 'all' ? 'الكل' : contentTypeLabels[type]}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Subject */}
      <div>
        <label className="text-sm font-medium mb-3 block">المادة</label>
        <Select 
          value={filters.subject} 
          onValueChange={(value) => setFilters({ ...filters, subject: value })}
        >
          <SelectTrigger className="h-12">
            <SelectValue placeholder="اختر المادة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المواد</SelectItem>
            {subjects.map((subject) => (
              <SelectItem key={subject.id} value={subject.id}>
                {subject.name} ({subject.code})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Level */}
      <div>
        <label className="text-sm font-medium mb-3 block">المستوى الدراسي</label>
        <Select 
          value={filters.level} 
          onValueChange={(value) => setFilters({ ...filters, level: value })}
        >
          <SelectTrigger className="h-12">
            <SelectValue placeholder="اختر المستوى" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المستويات</SelectItem>
            {levels.map((level) => (
              <SelectItem key={level.value} value={level.value.toString()}>
                {level.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Academic Year */}
      <div>
        <label className="text-sm font-medium mb-3 block">العام الدراسي</label>
        <Select 
          value={filters.academicYear} 
          onValueChange={(value) => setFilters({ ...filters, academicYear: value })}
        >
          <SelectTrigger className="h-12">
            <SelectValue placeholder="اختر العام الدراسي" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع السنوات</SelectItem>
            {academicYears.map((year) => (
              <SelectItem key={year} value={year}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Sort By */}
      <div>
        <label className="text-sm font-medium mb-3 block">ترتيب حسب</label>
        <Select 
          value={filters.sortBy} 
          onValueChange={(value) => setFilters({ ...filters, sortBy: value })}
        >
          <SelectTrigger className="h-12">
            <SelectValue placeholder="ترتيب حسب" />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Clear Filters */}
      {activeFiltersCount > 0 && (
        <Button
          variant="outline"
          className="w-full"
          onClick={clearFilters}
        >
          <X className="w-4 h-4 ml-2" />
          مسح الفلاتر ({activeFiltersCount})
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div 
          className={`mb-8 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">البحث في الملفات</h1>
          <p className="text-muted-foreground">ابحث في ملفات تخصصك وجامعتك</p>
        </div>

        {/* Search & Filter Bar */}
        <div 
          className={`bg-white rounded-2xl shadow-lg border border-gray-100 p-4 mb-8 transition-all duration-700 delay-100 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Input */}
            <div className="flex-1 relative">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="ابحث عن ملف، مادة، أو وصف..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-14 pr-12 text-base rounded-xl border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Desktop Filters */}
            <div className="hidden lg:flex items-center gap-3">
              <Select 
                value={filters.contentType} 
                onValueChange={(value) => setFilters({ ...filters, contentType: value as ContentType | 'all' })}
              >
                <SelectTrigger className="h-14 w-40 rounded-xl">
                  <SelectValue placeholder="نوع المحتوى" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  {(['lecture', 'book', 'summary', 'exam'] as const).map((type) => (
                    <SelectItem key={type} value={type}>
                      {contentTypeLabels[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select 
                value={filters.sortBy} 
                onValueChange={(value) => setFilters({ ...filters, sortBy: value })}
              >
                <SelectTrigger className="h-14 w-40 rounded-xl">
                  <SelectValue placeholder="الترتيب" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* View Mode Toggle */}
              <div className="flex items-center bg-gray-100 rounded-xl p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-3 rounded-lg transition-all duration-300 ${
                    viewMode === 'grid'
                      ? 'bg-white text-emerald-600 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Grid3X3 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-3 rounded-lg transition-all duration-300 ${
                    viewMode === 'list'
                      ? 'bg-white text-emerald-600 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Mobile Filter Button */}
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild>
                <Button 
                  variant="outline" 
                  className="lg:hidden h-14 rounded-xl relative"
                >
                  <SlidersHorizontal className="w-5 h-5 ml-2" />
                  فلترة
                  {activeFiltersCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 bg-emerald-500 text-white">
                      {activeFiltersCount}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full sm:max-w-md">
                <SheetHeader>
                  <SheetTitle>فلترة النتائج</SheetTitle>
                </SheetHeader>
                <div className="mt-6">
                  <FilterContent />
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Active Filters */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-gray-100">
              <span className="text-sm text-muted-foreground">الفلاتر النشطة:</span>
              {filters.contentType !== 'all' && (
                <Badge variant="secondary" className="gap-1">
                  {contentTypeLabels[filters.contentType]}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => setFilters({ ...filters, contentType: 'all' })}
                  />
                </Badge>
              )}
              {filters.subject !== 'all' && (
                <Badge variant="secondary" className="gap-1">
                  {subjects.find(s => s.id === filters.subject)?.name}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => setFilters({ ...filters, subject: 'all' })}
                  />
                </Badge>
              )}
              {filters.level !== 'all' && (
                <Badge variant="secondary" className="gap-1">
                  المستوى {filters.level}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => setFilters({ ...filters, level: 'all' })}
                  />
                </Badge>
              )}
              {filters.academicYear !== 'all' && (
                <Badge variant="secondary" className="gap-1">
                  {filters.academicYear}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => setFilters({ ...filters, academicYear: 'all' })}
                  />
                </Badge>
              )}
              <button
                onClick={clearFilters}
                className="text-sm text-emerald-600 hover:text-emerald-700 ml-auto"
              >
                مسح الكل
              </button>
            </div>
          )}
        </div>

        {/* Results Count */}
        <div 
          className={`flex items-center justify-between mb-6 transition-all duration-700 delay-200 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <p className="text-muted-foreground">
            تم العثور على <span className="font-bold text-foreground">{filteredFiles.length}</span> ملف
          </p>
        </div>

        {/* Results Grid/List */}
        {filteredFiles.length > 0 ? (
          <div className={viewMode === 'grid' 
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            : 'flex flex-col gap-4'
          }>
            {filteredFiles.map((file, index) => (
              <div 
                key={file.id}
                className={`transition-all duration-500 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${300 + index * 50}ms` }}
              >
                <FileCard file={file} viewMode={viewMode} />
              </div>
            ))}
          </div>
        ) : (
          <div 
            className={`text-center py-16 transition-all duration-700 delay-300 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          >
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
              <Search className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">لا توجد نتائج</h3>
            <p className="text-muted-foreground mb-6">جرب تغيير معايير البحث أو الفلاتر</p>
            <Button onClick={clearFilters} variant="outline">
              مسح الفلاتر
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
